import { Component, OnInit } from '@angular/core';
import { SignupService } from './../signup.service';
import{Router} from '@angular/router';
import { Signup } from '../signup';
import {Login} from '../login';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login:Login;
  signup: Signup;
  regid:number;
  
  
 
  constructor(private service: SignupService, private router: Router) { }

  ngOnInit(): void {
    this.login=new Login();
  }

  Login() {
    
    // make service call to get student object
    this.service.getOneSignup(this.login.regid).subscribe(
      data=>{
        this.signup=data;
        if(this.login.regid==this.signup.regid && this.login.password==this.signup.password)
        {
          this.router.navigate(['add']);
        }
        else
        {
          console.log('red');
          alert('incorrectlogin details');
        }
        console.log(this.signup);
        console.log(this.login.regid);
    }, error => {
      console.log(error);
    });


      
}
}