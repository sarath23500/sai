

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/singnup")
public class singnup extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		    res.setContentType("text/html");
		    PrintWriter pw=res.getWriter();
		    String a=req.getParameter("t1");
		    String b=req.getParameter("t2");
		    String c=req.getParameter("t3");
		    String d=req.getParameter("t4");
		    try
		    {
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
		    PreparedStatement st=con.prepareStatement("insert into signup values(?,?,?,?)");
		    st.setString(1,a);
		    st.setString(2,b);
		    st.setString(3,c);
		    st.setString(4,d);
		    st.execute();
		    res.sendRedirect("single.html");
		            }
		    catch(Exception ae)
		    {
		    ae.printStackTrace();
	        }
		    }
	}
/*create a application to register patient for corona.
patient can book the bed with or without oxygen.
patient can give the feed back.
Home
About Us
Registration/Login
Book bed with oxygen
FeedBack*/
