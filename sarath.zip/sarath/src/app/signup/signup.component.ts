import { Component, OnInit } from '@angular/core';
import { Signup } from '../signup';
import { SignupService } from '../signup.service';
import{Router} from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signup: Signup;
  message: string;
  constructor(private service: SignupService,private router: Router) { }

  ngOnInit(): void {

    this.signup=new Signup();
    
  }
  createSignup() {
    this.service.createSignup(this.signup)
    .subscribe(data => {
       // read message
       this.message = data;
      this.signup = new Signup(); // clear form
      alert('you have successfully registered');
      this.router.navigate(['login']);
      
    
    }, error => {
      console.log(error);
    });
  }

}
