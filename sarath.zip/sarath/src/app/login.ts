export class Login{
  regid:number;
    email:string;
    password:string;

  }