import { FeedbackService } from './../feedback.service';
import { Feedback } from './../feedback';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allfeedbacks',
  templateUrl: './allfeedbacks.component.html',
  styleUrls: ['./allfeedbacks.component.css']
})
export class AllfeedbacksComponent implements OnInit {
  // send this data to UI
  feedbacks: Feedback[];
  message: string;
  // inject service layer
  constructor(private service: FeedbackService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllFeedbacks();
  }
  // fetch data from backend application using service
  // tslint:disable-next-line: typedef
  getAllFeedbacks() {
    return this.service.getAllFeedbacks()
    .subscribe(
      data => {
        this.feedbacks = data;
      }, error => {
        console.log(error);
      }
    );
  }

  

  // tslint:disable-next-line: typedef
  editFeedback(id2: number) {
    this.router.navigate(['edit', id2]);
  }

}
