import { StudentEditComponent } from './student-edit/student-edit.component';
import { StudentCreateComponent } from './student-create/student-create.component';
import { StudentAllComponent } from './student-all/student-all.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';

import { SignupComponent } from './signup/signup.component';
import{FeedbackComponent} from './feedback/feedback.component';
import {AllfeedbacksComponent}from './allfeedbacks/allfeedbacks.component';
import{ContactComponent} from './contact/contact.component';
import{JobsComponent} from './jobs/jobs.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {path:'feedback',component:FeedbackComponent},
  {path:'contact',component:ContactComponent},
  {path:'jobs',component:JobsComponent},
  {path:'allfeedbacks',component:AllfeedbacksComponent},
  {path: 'signup', component:SignupComponent},
  {path: 'home', component:HomeComponent},
  {path: 'login', component:LoginComponent},
  {path: 'all', component: StudentAllComponent},
  {path: 'add', component: StudentCreateComponent},
  {path: 'edit/:id', component: StudentEditComponent},
  {path: '', redirectTo: 'home', pathMatch: 'full'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
