import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Signup} from './signup';



@Injectable({
  providedIn: 'root'
})
export class SignupService {

  private basePath = 'http://localhost:8090/rest/signup';

  constructor(private http: HttpClient) { }


  getOneSignup(regid:number): Observable<Signup> {
    return this.http.get<Signup>(`${this.basePath}/one/${regid}`);
  }

  createSignup(signup: Signup): Observable<any> {
    return this.http.post(`${this.basePath}/save`, signup, {responseType: 'text'});
  }

  

}
