package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;

import in.nareshit.raghu.model.Signup;


@Component
public class SignupUtil {

	public void mapToActualObject(Signup actual, Signup signup) {
		if(signup.getFirstname()!=null)
			actual.setFirstname(signup.getFirstname());
		actual.setLastname(signup.getLastname());
		if(signup.getEmail()!=null)
			actual.setEmail(signup.getEmail());
		actual.setAddress(signup.getAddress());
	}
	
}
