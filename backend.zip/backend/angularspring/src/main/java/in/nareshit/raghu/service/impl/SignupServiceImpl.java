package in.nareshit.raghu.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nareshit.raghu.model.Signup;
import in.nareshit.raghu.model.Student;
import in.nareshit.raghu.repo.SignupRepository;
import in.nareshit.raghu.repo.StudentRepository;
import in.nareshit.raghu.service.ISignupService;
import in.nareshit.raghu.service.IStudentService;

@Service
public class SignupServiceImpl implements ISignupService {

	@Autowired
	private SignupRepository repo;
	
	public Integer saveSignup(Signup s1) {
		s1 = repo.save(s1);
		return s1.getId1();
	}
    
	@Override
	public Optional<Signup> getOneSignup(Integer regid) {
		return repo.findById(regid);
	}
}
