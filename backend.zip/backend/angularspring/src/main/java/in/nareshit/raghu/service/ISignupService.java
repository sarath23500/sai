package in.nareshit.raghu.service;

import java.util.Optional;

import in.nareshit.raghu.model.Signup;
import in.nareshit.raghu.model.Student;



public interface ISignupService {

	Integer saveSignup(Signup s1);
	Optional<Signup> getOneSignup(Integer regid);
	
	 
	
}