package in.nareshit.raghu.util;

import org.springframework.stereotype.Component;


import in.nareshit.raghu.model.Student;

@Component
public class StudentUtil {

	public void mapToActualObject(Student actual, Student student) {
		if(student.getName()!=null)
			actual.setName(student.getName());
		actual.setCompany(student.getCompany());
		actual.setGender(student.getGender());
		actual.setDate1(student.getDate1());
        actual.setPhone(student.getPhone());
        actual.setQuali(student.getQuali());
        if(student.getEmail()!=null)
            actual.setEmail(student.getEmail());
        actual.setAddr(student.getAddr());
	}
	
}
